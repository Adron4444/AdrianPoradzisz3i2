import java.util.Arrays;
import java.util.Locale;
import java.util.Scanner;

public class Basic {
    public static void main(String[] args) {
//        IO.prostokat.main();
//        IO.pierwiastek.main(args);
        IO.objetoscKuli.main(args);
    }
}
