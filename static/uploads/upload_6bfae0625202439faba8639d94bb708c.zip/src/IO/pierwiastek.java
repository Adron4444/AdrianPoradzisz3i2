package IO;

public class pierwiastek {
    public static void main(String[] args) {
        System.out.println("Program wyświetla pierwiastek kwadratowy");
        System.out.println("z liczby pi z dokładnością do dwóch miejsc po przecinku.");
        System.out.printf("Math.sqrt(Pi)= %.2f", Math.sqrt(Math.PI));
        System.out.printf("Math.sqrt(Pi)= %.5f", Math.sqrt(Math.PI));
    }
}
