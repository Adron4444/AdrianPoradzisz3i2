package IO;

import java.util.Scanner;

public class objetoscKuli {
    public static void main(String[] args) {
        System.out.println("Podaj promień");
        Scanner sc = new Scanner(System.in);
        double r = Double.parseDouble(sc.nextLine());
        double pole = 4 * Math.PI * r * r * r / 3;
        System.out.printf("Objętość kuli o promieniu r = %.2f wynosi %.2f",r,pole);
    }
}
