package IO;

import java.util.Scanner;

public class prostokat {
    public static void main() {
        System.out.println("Program oblicza pole prostokata.");
        System.out.println("Podaj bok a:");
        Scanner sc = new Scanner(System.in);
        double a = Double.parseDouble(sc.nextLine());
        System.out.println("Podaj bok a:");
        double b = Double.parseDouble(sc.nextLine());
        double pole = a * b;
        System.out.println("Pole prostokąta o boku a = " + a + " i boku b =  " + b + " wynosi " + pole);
    }
}
