var express = require("express");
var app = express();
const PORT = 3000;

var hbs = require('express-handlebars');
var formidable = require('formidable');
const path = require("path");

app.set('views', path.join(__dirname, 'views'));

app.engine('hbs', hbs({ defaultLayout: 'main.hbs' }));

app.get('/', function (req, res) {
    res.render('uploads.hbs')
});
var jsonFile;
app.post('/upload', function (req, res) {
    let form = formidable({});
    form.multiples = true;
    form.keepExtensions = true;
    form.uploadDir = __dirname + '/static/uploads/'
    form.parse(req, function (err, fields, files) {
        console.log(files.upload[0]);
        jsonFile = files
        res.redirect('/filemanager');
    });
});

app.get('/filemanager', function (req, res) {
    res.render('filemanager.hbs', jsonFile)
});

app.get('/info/', function (req, res) {
    console.log(req.query.id)
    console.log(jsonFile.upload[req.query])
    res.render('info.hbs', jsonFile.upload[req.query.id]);
});

app.use(express.static('static'))

app.listen(PORT, function () {
    console.log("start serwera na porcie " + PORT)
});